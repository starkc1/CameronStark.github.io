package application;
public class AirportInfo {
	
	//static String[] (name)Array = { (Name), (Map), (Tower?), (ARTCC), (Elevation (ft)), (Unicom), (ATIS), (Ground), (Tower), (international) }
	
	static String[] kdabArray = {"Daytona Beach International (KDAB)","images/KDAB.jpg", "Yes", "Jacksonville Center", "34", "122.95", "132.875", "121.9 348.9", "120.7 257.8 118.1", "No"};
	static String[] ktpaArray = {"Tampa International (KTPA)", "images/KTPA.jpg", "Yes", "Miami Center", "26", "122.95", "126.45", "121.7 269.4 121.35", "119.5 269.4 119.05", "No"};
	static String[] kdcaArray = {"Ronald Reagan Washington National (KDCA)", "images/KDCA.jpg", "Yes", "Washingtion Center", "14", "122.95", "Not Present", "121.7 257.6", "119.1 134.35(HELICOPTERS) 257.6", "No"};
	static String[] kmcoArray = {"Orlando International (KMCO)", "images/KMCO.jpg", "Yes", "Jacksonville Center", "96", "125.95", "Not Present", "121.8 WEST 126.4 EAST 275.8 EAST WEST", "118.45 124.3 253.5", "No" }; 
}